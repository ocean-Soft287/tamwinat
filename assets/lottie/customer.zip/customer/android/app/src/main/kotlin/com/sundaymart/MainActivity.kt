package net.sundaymart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
